title: 让ORM支持多结果集
date: '2019-07-01 09:35:40'
updated: '2019-07-02 08:28:35'
tags: [netcore, 技巧]
permalink: /articles/2019/07/01/1561944940892.html
---
在现有的ORM框架中，都支持查询单个结果集。比如查询用户表，传入语句，返回一个用户对象的集合。虽然一次性查询多个结果集的情况不多，而且也可以通过多次查询得到，但是从写框架的角度来说，我们并不清楚客户（其他Developer）期望怎么使用我们的框架。（当我写这篇文章的时候，搜索了一下,EF和Dapper都有实现多结果集查询，从其调用来看和我的的思路差不多）

实现多结果集的关键就是方法签名。单个结果集的时候我们可以这样定义：

`public List<TModel> Select<TModel>(string sql)`

因为是ORM框架，我们需要返回泛型结果，使用泛型的限制是，每个泛型参数必须在声明的时候定义好，比如我们返回两个结果集可以这样定义：

`public Tuple<List<T1>,List<T2>> Select<T1,T2>(string sql1,string sql2)`

这种定义当然是可以实现的，但是存在的问题也很明显，比如我们返回三个结果集的时候，需要再加一个重载：

`public Tuple<List<T1>,List<T2>,List<T3>> Select<T1,T2,T3>(string sql1,string sql2,string sql3)`

如果是四个、五个、更多呢？还有可能不全是List，或者是单个模型呢，再加上顺序的问题会有很多组合，这个时候我就要宣布自己精力有限啦。

上述方法可行性不好，需要换一下角度。之所以定义会那么多，是有两方面原因：

    1、我们一次性返回了多个结果集

    2、泛型参数需要声明时定义好

所以上面的实现属于“强为之”，不可取。**当我们控制不了一些事物变化的时候，我们应该学会放权，把决策权给用户**，落实到文章的主题，有两个不可控：

    1、我们不知道用户要查询几个结果集

    2、我们不知道每一个结果集返回什么类型

为了方便传参，我们定义一个命令对象，包括sql语句和sql参数：

```
    public class MutipleCmd
    { /// <summary>
        /// sql语句 /// </summary>
        public string CmdText { get; set; } public Dictionary<string, object> Params { get; set; }
    }
```

在查询多结果集的时候，我们就可以传入MutipleCmd类型的参数数组了。

因为不知道多个结果分别对应什么类型，所以我们的返回值并不能像上面那样直接出去，而是要定义个很关键的结果类，提供方法让用户自己去结果：

```
    /// <summary>
    /// 查询多个结果集时，返回此类型的对象，客户端手动Fetch /// </summary>
    public class MutipleResult : IDisposable
    { #region 实现Dispose
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        } public void Close()
        {
            Dispose();
        } ~MutipleResult()
        {
            Dispose(false);
        } private bool disposed = false; protected virtual void Dispose(bool disposing)
        { if (disposed) return; if (disposing)
            { //释放托管资源
 } if (_reader != null)
            {
                _reader.Dispose();
            }
            disposed = true;
        } #endregion DbDataReader _reader; public MutipleResult() { } public MutipleResult(DbDataReader reader)
        {
            _reader = reader;
        } /// <summary>
        /// 从DataReader获取多行数据，填充为TModel集合返回 /// </summary>
        /// <typeparam name="TModel"></typeparam>
        /// <returns></returns>
        public List<TModel> FetchList<TModel>()
        { if (_reader == null || _reader.IsClosed) return new List<TModel>(); var list = Mapping.ReaderToObjectList<TModel>(_reader); if (!_reader.NextResult())
            {
                _reader.Close();
            } return list;
        } /// <summary>
        /// 从DataReader获取一行数据，填充为TModel返回 /// </summary>
        /// <typeparam name="TModel"></typeparam>
        /// <returns></returns>
        public TModel FetchObject<TModel>()
        { if (_reader == null || _reader.IsClosed) return default(TModel); var m = Mapping.ReaderToObject<TModel>(_reader); if (!_reader.NextResult())
            {
                _reader.Close();
            } return m;
        } /// <summary>
        /// 从DataReader获取首行首列的值 /// </summary>
        /// <typeparam name="TValue"></typeparam>
        /// <returns></returns>
        public TValue FetchScalar<TValue>()
        { if (_reader == null || _reader.IsClosed) return default(TValue); var scalar = Mapping.ReaderToScalar<TValue>(_reader); if (!_reader.NextResult())
            {
                _reader.Close();
            } return scalar;
        }
    }
```

定义的MutipleResult类由于引用的DataReader，要实现以下IDisposable接口以方便用户用using语法关闭DataReader。还提供了三个Fetch方法用于获取Mapping好的结果，也可以提供更多有特性的Fetch方法，这里我只实现了自己感觉常用的。

还有一点需要注意一下，传入的多个MutipleCmd参数之中的sql参数可能因同名而相互影响，所以我们在MutipleCmd方法里再加两个方法：

```
        internal Dictionary<string, object> GetUniqueParams(int index)
        { if (Params == null || Params.Count == 0) return new Dictionary<string, object>(); var newParams = new Dictionary<string, object>(); foreach (var kv in Params)
            {
                newParams.Add(kv.Key + "_" + index, kv.Value);
            } return newParams;
        } internal string GetMatchedCmdText(int index)
        { if (Params == null || Params.Count == 0) return CmdText; var newSql = CmdText; foreach (var item in Params)
            {
                newSql = newSql.Replace("@" + item.Key, "@" + item.Key + "_" + index);
            } return newSql;
        }
```

这两个方法用于使一次查询中的sql参数唯一，在实际查询方法中，我们只是简单的拼接语句和组合sql参数，获取datareader即可：

```
/// <summary>
        /// 执行命令，返回多个结果集，返回对象用using释放，Fetch结果的时候最好不要做其他逻辑 /// </summary>
        /// <param name="dbConn"></param>
        /// <param name="cmds"></param>
        /// <returns></returns>
        public static MutipleResult SelectMutipleResult(this DbConnection dbConn, params MutipleCmd[] cmds)
        { if (cmds == null || cmds.Length == 0) return new MutipleResult(); var theCmd = BaseCmd.GetCmd(dbConn.GetProviderType());

            List<string> sqls = new List<string>();
            List<DbParameter> ps = new List<DbParameter>(); for (int i = 0; i < cmds.Length; i++)
            { var cmd = cmds[i];
                sqls.Add(cmd.GetMatchedCmdText(i));
                ps.AddRange(theCmd.DictionaryToParams(cmd.GetUniqueParams(i)));
            } var sql = string.Join(";", sqls); var reader = SqlHelper.ExecuteReader(dbConn, CommandType.Text, sql, ps.ToArray()); return new MutipleResult(reader);
        }
```

使用的例子：

```
        static void TestMutileResult()
        { using (var db = Utils.CreateConnection())
            { var cmds = new MutipleCmd[] { new MutipleCmd { CmdText="select top 2 * from TestEntity" }, new MutipleCmd { CmdText="select top 1 * from TestEntity where F_Int64>@fint", Params=new Dictionary<string, object> { {"fint",23 } } }, new MutipleCmd { CmdText="select top 1 F_Int64 from TestEntity where F_Int64>@fint",Params=new Dictionary<string, object> { {"fint",20 } } },
                }; var result = db.SelectMutipleResult(cmds); var list = result.FetchList<TestEntity>(); var entity = result.FetchObject<TestEntity>(); var f_int64 = result.FetchScalar<long>();

                Console.WriteLine(list[1].F_String);
                Console.WriteLine(entity.F_String);
                Console.WriteLine(f_int64);
            }
        }
```

如SelectMutipleResult方法的注释所说，Fetch结果的时候最好不要做其他操作，因为Fetch的时候DataReader一直连接着数据库，长时间的连接对性能影响较大。说好的调用SelectMutipleResult时要使用using呢，其实可用可不用，因为外部连接会关闭，而且如果常规调用，Fetch到最后一个结果集的时候会自动关闭掉Reader。

因为是在自己的ORM里实现的，以上代码都源自[Loogn.OrmLite](https://gitee.com/loogn/Loogn.OrmLite)。