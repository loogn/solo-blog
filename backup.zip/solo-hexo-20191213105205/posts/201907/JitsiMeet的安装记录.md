title: Jitsi Meet的安装记录
date: '2019-07-10 09:37:52'
updated: '2019-07-10 09:37:58'
tags: [jitsi]
permalink: /jitsi-meet
---
Jitsi Meet是一个基于WebRTC的开源应用程序，通过jitsi videobridge可以提供高质量、安全、可可扩展的视频会议。由于是基于WebRTC运行在浏览器中，所有不需要在计算机上安装任何软件。这篇文章是记录自己在部署JitsiMeet中的步骤和问题，以及解决方法。(我是直接使用root操作的，如果你使用的不是root用户，请在命令前加sudo)

操作系统：
Ubuntu 16.04.6 LTS，代号：xenial

安装jdk:
`apt install openjdk-8-jdk`

安装nginx:
`apt install nginx`

安装apt-https:
`apt install apt-transport-https`

安装wget:
`apt install wget`

添加jitsi的仓库：
```
echo 'deb [https://download.jitsi.org](https://download.jitsi.org) stable/' >> /etc/apt/sources.list.d/jitsi-stable.list  
wget -qO - [https://download.jitsi.org/jitsi-key.gpg.key](https://download.jitsi.org/jitsi-key.gpg.key) | apt-key add -
apt update
```

安装jitsi meet:
`apt -y install jitsi-meet`
中间会输入域名等信息

生成https证书：
`/usr/share/jitsi-meet/scripts/install-letsencrypt-cert.sh`
这里注意留意终端的输出，会提示证书的位置

---
以上部分jitsi-meet就安装好了,下面是安装tokens插件

安装prosody-trunk:
在连接中找到操作系统的对应版本 [prosody-trunk](https://packages.prosody.im/debian/pool/main/p/prosody-trunk/)
```
wget [https://packages.prosody.im/debian/pool/main/p/prosody-trunk/prosody-trunk_1nightly635-1~xenial_amd64.deb](https://packages.prosody.im/debian/pool/main/p/prosody-trunk/prosody-trunk_1nightly635-1~xenial_amd64.deb) 
dpkg -i prosody-trunk_1nightly635-1~xenial_amd64.deb
```

安装token插件：
`apt-get install jitsi-meet-tokens`
中间会输入信息，安装好在配置文件中也能看到

如果出现错误basexx安装失败：
```
wget [https://github.com/aiq/basexx/archive/v0.4.1.tar.gz](https://github.com/aiq/basexx/archive/v0.4.1.tar.gz)
tar -xzvf v0.4.1.tar.gz
cd basexx-0.4.1
luarocks make dist/basexx-scm-0.rockspec
```
如果缺少[luajwtjitsi](http://luarocks.org/modules/pawelgawel88/luajwtjitsi):
`luarocks install luajwtjitsi`


luajwtjitsi的依赖可能安装不成功，需要手动安装下面两个
lua-cjson >= 2.1.0
luacrypto >= 0.3.2-1

修改配置文件
在 /etc/prosody/prosody.cfg.lua追加内容
Include "conf.d/*.cfg.lua"

至此安装完成

卸载：
`apt purge jigasi jitsi-meet jitsi-meet-web-config jitsi-meet-prosody jitsi-meet-web jicofo jitsi-videobridge`


