title: nginx中location的匹配规则
date: '2019-07-17 18:09:12'
updated: '2019-07-17 18:09:12'
tags: [nginx]
permalink: /articles/2019/07/17/1563358152945.html
---
nginx中location的匹配方式有以下几种：
1. 普通匹配，如location / { } ,location /upload { } 
2. 精确匹配，在普通匹配前面加=,如location = /{ },匹配成功停止
3. 正则匹配，~ 后面加正则，如location ~ \.flv$ { }，
4. 正则匹配，不区分大小写 \~* 后面加正则，如location \~* \.flv$ { } 
5. 阻止正则，在普通匹配前面加^~ ，如location \^~ /upload{ }

根据匹配的规则画出的流程图：
![未命名文件1.jpg](https://img.hacpai.com/file/2019/07/未命名文件1-0f8b1575.jpg)




