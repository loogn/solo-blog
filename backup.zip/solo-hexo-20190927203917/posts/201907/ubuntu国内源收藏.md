title: ubuntu国内源收藏
date: '2019-07-09 09:23:09'
updated: '2019-07-09 09:23:09'
tags: [linux]
permalink: /articles/2019/07/09/1562635389870.html
---
**备份文件**
`cp /etc/apt/sources.list /etc/apt/sources.list.bak`
在/etc/apt/sources.list文件头部可添加如下的国内源

**阿里源**
 ```  
deb [http://mirrors.aliyun.com/ubuntu/](http://mirrors.aliyun.com/ubuntu/) bionic main restricted universe multiverse
deb [http://mirrors.aliyun.com/ubuntu/](http://mirrors.aliyun.com/ubuntu/) bionic-security main restricted universe multiverse
deb [http://mirrors.aliyun.com/ubuntu/](http://mirrors.aliyun.com/ubuntu/) bionic-updates main restricted universe multiverse
deb [http://mirrors.aliyun.com/ubuntu/](http://mirrors.aliyun.com/ubuntu/) bionic-proposed main restricted universe multiverse
deb [http://mirrors.aliyun.com/ubuntu/](http://mirrors.aliyun.com/ubuntu/) bionic-backports main restricted universe multiverse
deb-src [http://mirrors.aliyun.com/ubuntu/](http://mirrors.aliyun.com/ubuntu/) bionic main restricted universe multiverse
deb-src [http://mirrors.aliyun.com/ubuntu/](http://mirrors.aliyun.com/ubuntu/) bionic-security main restricted universe multiverse
deb-src [http://mirrors.aliyun.com/ubuntu/](http://mirrors.aliyun.com/ubuntu/) bionic-updates main restricted universe multiverse
deb-src [http://mirrors.aliyun.com/ubuntu/](http://mirrors.aliyun.com/ubuntu/) bionic-proposed main restricted universe multiverse
deb-src [http://mirrors.aliyun.com/ubuntu/](http://mirrors.aliyun.com/ubuntu/) bionic-backports main restricted universe multiverse
```
**中科大源**
```
deb [https://mirrors.ustc.edu.cn/ubuntu/](https://mirrors.ustc.edu.cn/ubuntu/) bionic main restricted universe multiverse
deb-src [https://mirrors.ustc.edu.cn/ubuntu/](https://mirrors.ustc.edu.cn/ubuntu/) bionic main restricted universe multiverse
deb [https://mirrors.ustc.edu.cn/ubuntu/](https://mirrors.ustc.edu.cn/ubuntu/) bionic-updates main restricted universe multiverse
deb-src [https://mirrors.ustc.edu.cn/ubuntu/](https://mirrors.ustc.edu.cn/ubuntu/) bionic-updates main restricted universe multiverse
deb [https://mirrors.ustc.edu.cn/ubuntu/](https://mirrors.ustc.edu.cn/ubuntu/) bionic-backports main restricted universe multiverse
deb-src [https://mirrors.ustc.edu.cn/ubuntu/](https://mirrors.ustc.edu.cn/ubuntu/) bionic-backports main restricted universe multiverse
deb [https://mirrors.ustc.edu.cn/ubuntu/](https://mirrors.ustc.edu.cn/ubuntu/) bionic-security main restricted universe multiverse
deb-src [https://mirrors.ustc.edu.cn/ubuntu/](https://mirrors.ustc.edu.cn/ubuntu/) bionic-security main restricted universe multiverse
deb [https://mirrors.ustc.edu.cn/ubuntu/](https://mirrors.ustc.edu.cn/ubuntu/) bionic-proposed main restricted universe multiverse
deb-src [https://mirrors.ustc.edu.cn/ubuntu/](https://mirrors.ustc.edu.cn/ubuntu/) bionic-proposed main restricted universe multiverse
```
**清华源**
```
deb [https://mirrors.tuna.tsinghua.edu.cn/ubuntu/](https://mirrors.tuna.tsinghua.edu.cn/ubuntu/) bionic main restricted universe multiverse
deb-src [https://mirrors.tuna.tsinghua.edu.cn/ubuntu/](https://mirrors.tuna.tsinghua.edu.cn/ubuntu/) bionic main restricted universe multiverse
deb [https://mirrors.tuna.tsinghua.edu.cn/ubuntu/](https://mirrors.tuna.tsinghua.edu.cn/ubuntu/) bionic-updates main restricted universe multiverse
deb-src [https://mirrors.tuna.tsinghua.edu.cn/ubuntu/](https://mirrors.tuna.tsinghua.edu.cn/ubuntu/) bionic-updates main restricted universe multiverse
deb [https://mirrors.tuna.tsinghua.edu.cn/ubuntu/](https://mirrors.tuna.tsinghua.edu.cn/ubuntu/) bionic-backports main restricted universe multiverse
deb-src [https://mirrors.tuna.tsinghua.edu.cn/ubuntu/](https://mirrors.tuna.tsinghua.edu.cn/ubuntu/) bionic-backports main restricted universe multiverse
deb [https://mirrors.tuna.tsinghua.edu.cn/ubuntu/](https://mirrors.tuna.tsinghua.edu.cn/ubuntu/) bionic-security main restricted universe multiverse
deb-src [https://mirrors.tuna.tsinghua.edu.cn/ubuntu/](https://mirrors.tuna.tsinghua.edu.cn/ubuntu/) bionic-security main restricted universe multiverse
deb [https://mirrors.tuna.tsinghua.edu.cn/ubuntu/](https://mirrors.tuna.tsinghua.edu.cn/ubuntu/) bionic-proposed main restricted universe multiverse
deb-src [https://mirrors.tuna.tsinghua.edu.cn/ubuntu/](https://mirrors.tuna.tsinghua.edu.cn/ubuntu/) bionic-proposed main restricted universe multiverse
```
**163源**
```
deb [http://mirrors.163.com/ubuntu/](http://mirrors.163.com/ubuntu/) bionic main restricted universe multiverse
deb [http://mirrors.163.com/ubuntu/](http://mirrors.163.com/ubuntu/) bionic-security main restricted universe multiverse
deb [http://mirrors.163.com/ubuntu/](http://mirrors.163.com/ubuntu/) bionic-updates main restricted universe multiverse
deb [http://mirrors.163.com/ubuntu/](http://mirrors.163.com/ubuntu/) bionic-proposed main restricted universe multiverse
deb [http://mirrors.163.com/ubuntu/](http://mirrors.163.com/ubuntu/) bionic-backports main restricted universe multiverse
deb-src [http://mirrors.163.com/ubuntu/](http://mirrors.163.com/ubuntu/) bionic main restricted universe multiverse
deb-src [http://mirrors.163.com/ubuntu/](http://mirrors.163.com/ubuntu/) bionic-security main restricted universe multiverse
deb-src [http://mirrors.163.com/ubuntu/](http://mirrors.163.com/ubuntu/) bionic-updates main restricted universe multiverse
deb-src [http://mirrors.163.com/ubuntu/](http://mirrors.163.com/ubuntu/) bionic-proposed main restricted universe multiverse
deb-src [http://mirrors.163.com/ubuntu/](http://mirrors.163.com/ubuntu/) bionic-backports main restricted universe multiverse
```
添加之后执行如下命令更新源
```
sudo apt-get update
sudo apt-get upgrade
```
